import hashlib,json,subprocess,sys
from pathlib import Path
phase=sys.argv[1]
records={}
for line in Path('/tmp/ninjars-rank-harness-'+phase+'-build.jsonl').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r.get('executable'):
  records[r['target']['name']]={'path':r['executable']}
for record in records.values():
 with open(record['path'],'rb') as f:record['sha256']=hashlib.file_digest(f,'sha256').hexdigest()
Path('/tmp/ninjars-rank-harness-'+phase+'-executables.json').write_text(json.dumps(records,indent=2)+'\n')
for name,pattern in [s.split(':',1) for s in sys.argv[2:]]:
 command=['flock','/tmp/ninjars-symbolica-tests.lock',records[name]['path'],pattern,'--test-threads=1','--nocapture']
 with open('/tmp/ninjars-rank-harness-'+phase+'-'+name+'-'+pattern+'.log','w') as out:
  r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 if r.returncode:sys.exit(r.returncode)
