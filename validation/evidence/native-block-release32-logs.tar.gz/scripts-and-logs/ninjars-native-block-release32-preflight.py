import hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd()
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert git('rev-parse','HEAD')=='8b868220f3a438a7f78e0e5329cd011646fef71c'
assert not git('status','--short')
dev=json.loads((root/'validation/evidence/native-block-harness.json').read_text())
deps=[]
for dep in dev['dependencies']:
 path='references/'+dep['name'];actual=git('-C',path,'rev-parse','HEAD')
 assert actual==dep['revision'];assert not git('-C',path,'status','--short','--untracked-files=no')
 deps.append({'name':dep['name'],'revision':actual,'tracked_clean':True})
artifacts=dict(dev['physical_artifacts_sha256'])
for phase in dev['test_executable_snapshots'].values():
 for artifact in phase.values():artifacts[artifact['preserved_path']]=artifact['sha256']
assert all(sha(path)==digest for path,digest in artifacts.items())
result={'source_revision':git('rev-parse','HEAD'),'dependencies':deps,'preserved_debug_artifacts':artifacts,'debug_evidence_sha256':sha(root/'validation/evidence/native-block-harness.json'),'release_bound_preselected':32,'build_cache':'/common/build-cache/external/83/908dcad578ed91','runtime_source_mutations':False}
pathlib.Path('/tmp/ninjars-native-block-release32-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print('Frozen source/dependencies and',len(artifacts),'debug/reference artifacts verified')
