"""Bind release correctness and preserved artifacts, without timing claims."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
out = root / 'target/validation/native-block-release32'
evidence = root / 'validation/evidence'
revision = '8b868220f3a438a7f78e0e5329cd011646fef71c'
widths = [0, 1, 3, 8, 31, 32, 128, 1024]

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(name):
    return json.loads((out / name).read_text())

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
base = read('result.json')
assert base['success'] and base['unchanged_runtime_sources'] and base['rust_profile'] == 'release'
sources = base['source_sha256']
assert all(sha(root / path) == digest for path, digest in sources.items())
dependencies = base['dependency_heads']
for name, head in dependencies.items():
    directory = root / 'references' / name
    assert subprocess.check_output(['git', '-C', directory, 'rev-parse', 'HEAD'], text=True).strip() == head
    assert not subprocess.check_output(['git', '-C', directory, 'status', '--porcelain', '--untracked-files=no'], text=True).strip()
preflight = json.loads(Path('/tmp/ninjars-native-block-release32-preflight.json').read_text())
assert all(sha(path) == digest for path, digest in preflight['preserved_debug_artifacts'].items())
primary = read('primary-execution.json')
replays = read('same-artifact-commands.json')
timing_build = read('timing-launcher-build.json')
assert primary['returncode'] == 0 and primary['unchanged']
assert len(replays) == 3
assert all(row['returncode'] == 0 and row['artifact_hashes_unchanged'] and row['sources_and_dependencies_unchanged'] for row in replays)
assert timing_build['returncode'] == 0 and not timing_build['execution_performed']
assert timing_build['library_before_sha256'] == timing_build['library_after_sha256']
assert all(row['returncode'] == 0 for row in base['commands'])
assert all(row['returncode'] == 0 for row in timing_build['loader_commands'])
reports = {name: read(name + '.json') for name in ['native-rank-fixed32', 'native-fixed32', 'native-denominators-fixed32', 'all-whole']}
total_components = 0
summary = {}
for name, report in reports.items():
    assert report['success'] and report['integrated_widths'] == widths
    parity = report['catalog_parity'] if name == 'all-whole' else report['execution_parity']
    assert len(parity) == (5 if name == 'all-whole' else 2)
    assert all(row['complex_components_checked'] == sum(widths) * 5 for row in parity)
    count = sum(row['complex_components_checked'] for row in parity)
    total_components += count
    summary[name] = {
        'selection': report['reduction_kernels'],
        'integrated_widths': report['integrated_widths'],
        'parity': parity,
        'parity_complex_components_checked': count,
        'raw_components_checked': report['raw_components_checked'],
        'raw_max_scaled_error': report['raw_max_scaled_error'],
        'coefficient_oracle_max_scaled_error': report['coefficient_oracle_max_scaled_error'],
        'changed_model_coefficient_oracle_max_scaled_error': report['changed_model_coefficient_oracle_max_scaled_error'],
        'jit_interpreter_max_scaled_error': report['jit_interpreter_max_scaled_error'],
        'integrated_max_scaled_error': report['integrated_max_scaled_error'],
        'madloop_integrated_max_scaled_error': report['madloop_integrated_max_scaled_error'],
        'batch_laurent_components_checked': report['batch_laurent_components_checked'],
        'preparation_failure_controls': report['preparation_failure_controls'],
        'transactional_preparation_checked': report['transactional_preparation_checked'],
        'master_union_entries': report['master_union_entries'],
    }
assert total_components == 67485
artifacts = dict(base['artifacts_sha256'])
artifacts[str(out / 'physical-timing')] = sha(out / 'physical-timing')
report_paths = [out / 'result.json'] + [out / (name + '.json') for name in reports]
reports_sha256 = {str(path): sha(path) for path in report_paths}
artifacts.update(reports_sha256)
assert all(sha(path) == digest for path, digest in artifacts.items())
for name in ['physical-probe', 'physical-timing', 'libninjars_shared_provider_probe.so']:
    assert (out / name).stat().st_mode & 0o222 == 0
loader = {}
for name in ['physical-probe', 'physical-timing']:
    needed, resolved = out / (name + '-needed.txt'), out / (name + '-loader.txt')
    assert str(out / 'libninjars_shared_provider_probe.so') in resolved.read_text()
    loader[name] = {
        'LD_LIBRARY_PATH': str(out),
        'needed_path': str(needed), 'needed_sha256': sha(needed), 'needed_text': needed.read_text(),
        'resolved_path': str(resolved), 'resolved_sha256': sha(resolved), 'resolved_text': resolved.read_text(),
    }
cargo_rows = [json.loads(line) for line in (out / 'cargo-build.stdout').read_text().splitlines() if line.startswith('{')]
provider_rows = [row for row in cargo_rows if row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'ninjars_shared_provider_probe']
assert len(provider_rows) == 1
assert 'native-kernels' in provider_rows[0]['features']
assert not any('diagnostics' in feature for feature in provider_rows[0]['features'])
feature_graph = [{'package_id': row['package_id'], 'target': row['target']['name'],
                  'features': row['features'], 'profile': row['profile'],
                  'filenames': row['filenames']}
                 for row in cargo_rows if row.get('reason') == 'compiler-artifact']
manifest = {
    'schema_version': 1,
    'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'Release same-artifact physical correctness passed; no timing samples or performance acceptance',
    'source_revision': revision,
    'source_checkout': str(root),
    'source_sha256': sources,
    'dependency_heads': dependencies,
    'artifacts_sha256': artifacts,
    'reports_sha256': reports_sha256,
    'output_directory': str(out),
    'integrated_widths': widths,
    'preselected_native_block_rows': 32,
    'native_block_scope': 'Full native kernel input rows, not phase-space lanes',
    'parity_complex_components_checked': total_components,
    'physical_controls': summary,
    'primary_rich_report': str(out / 'result.json'),
    'ordinary_timing_launcher': {'path': str(out / 'physical-timing'), 'executed': False},
    'loader_evidence': loader,
    'primary_execution': primary,
    'same_artifact_execution_commands': replays,
    'build_commands': base['commands'][:2],
    'timing_launcher_build': timing_build,
    'timing_compile_command': timing_build['argv'],
    'cargo_provider_artifact': provider_rows[0],
    'cargo_artifact_feature_graph': feature_graph,
    'cargo_build_json': {'path': str(out / 'cargo-build.stdout'), 'sha256': sha(out / 'cargo-build.stdout')},
    'build_cache': preflight['build_cache'],
    'compiler_environment': json.loads(Path('/tmp/ninjars-native-block-release32-environment.json').read_text()),
    'compiler_versions': read('compiler-versions.json'),
    'profile': {'rust': 'release', 'opt_level': '3 (Cargo default)', 'lto': 'thin', 'codegen_units': 1,
                'cpp_correctness': '-O2', 'cpp_timing_launcher': '-O3', 'fast_math': False},
    'execution_policy': {'maximum_build_jobs': 4, 'builds_outside_numerical_lock': True,
                         'numerical_lock': '/tmp/ninjars-symbolica-tests.lock',
                         'RAYON_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1'},
    'runtime_sources_unchanged': True,
    'dependency_heads_unchanged': True,
    'preserved_debug_artifacts_sha256': preflight['preserved_debug_artifacts'],
    'preserved_debug_artifacts_unchanged': True,
    'numerator_provider': base['numerator_provider'],
    'physical_input_boundary': base['physical_input_boundary'],
    'precision_oracle_boundary': base['precision_oracle_boundary'],
    'scope': base['scope'],
    'failures': [],
    'rational_separation_parity_complete': False,
    'production_backend_comparison': False,
    'performance_acceptance': False,
    'limits': [
        'No timing samples, speed claim, or performance acceptance. The ordinary timing launcher was compiled and loader-inspected only.',
        'Configured native coverage and block policy do not establish actual stage execution counts; a separate instrumented actual-master pass is pending.',
        'Physical correctness uses shared providers and matched master controls; it does not establish production-backend or complete rational-decomposition parity.',
        'Float256 oracle promotes binary64 inputs after wavefunction evaluation; it is not a high-precision physical wavefunction evaluation.',
        'Future fixed-row timings must independently verify these exact source/dependency/library/input identities, mode, bound32, full widths and parity reports; historical control acceptance or warmup metadata alone is insufficient.',
        'The following evidence-only commit changes checkout HEAD but does not change the frozen source revision or any runtime source hash.',
    ],
}
manifest_path = out / 'release-artifacts.json'
assert not manifest_path.exists()
manifest_path.write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')
for path in report_paths + [manifest_path]:
    path.chmod(0o444)

logs = {}
for path in sorted(Path('/tmp').glob('ninjars-native-block-release32-*')):
    if path.is_file() and path.suffix in {'.py', '.json', '.log'}:
        logs['scripts-and-logs/' + path.name] = path.read_bytes()
for path in sorted(out.iterdir()):
    if path.is_file() and path.suffix in {'.stdout', '.stderr', '.json', '.txt'}:
        logs['release/' + path.name] = path.read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(logs.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        archive.addfile(member, io.BytesIO(data))
archive_path = evidence / 'native-block-release32-logs.tar.gz'
archive_path.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
record = dict(manifest)
record['retained_manifest'] = {'path': str(manifest_path), 'sha256': sha(manifest_path)}
record['logs'] = {'archive': str(archive_path.relative_to(root)), 'sha256': sha(archive_path),
                  'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(logs.items())}}
(evidence / 'native-block-release32.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({'manifest': str(manifest_path), 'sha256': sha(manifest_path),
                  'parity_complex_components_checked': total_components, 'archive_members': len(logs)}, indent=2))
