"""Run only physical correctness with one frozen release artifact set."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
out = root / 'target/validation/native-block-release32'
sys.path.insert(0, str(root / 'validation/performance/shared_provider'))
from kernel_selection import validate_report

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read_raw(path):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 1, path
    return rows[0]

base = json.loads((out / 'result.json').read_text())
assert base['success'] and base['unchanged_runtime_sources']
assert base['rust_profile'] == 'release'
widths = [0, 1, 3, 8, 31, 32, 128, 1024]
assert base['integrated_widths'] == widths
artifacts = base['artifacts_sha256']
sources = base['source_sha256']

def verify():
    for path, digest in artifacts.items():
        assert sha(path) == digest, path
    for path, digest in sources.items():
        assert sha(root / path) == digest, path
    for name, head in base['dependency_heads'].items():
        actual = subprocess.check_output(['git', '-C', root / 'references' / name, 'rev-parse', 'HEAD'], text=True).strip()
        assert actual == head, name

def validate(result, selection, bound):
    assert result['success']
    assert result['integrated_widths'] == widths
    assert result['batch_laurent_components_checked'] == sum(widths) * 3
    assert len(result['rust']) == len(result['original']) == 15
    validate_report(result, 'symbolica' if selection == 'all' else selection, True,
                    all_catalog=selection == 'all', native_block_rows=bound,
                    execution_controls=bound is not None)
    parity = result['catalog_parity' if selection == 'all' else 'execution_parity']
    assert len(parity) == (5 if selection == 'all' else 2)
    for row in parity:
        assert row['complex_components_checked'] == sum(widths) * 5
        assert row['max_scaled_error'] <= 1e-9

verify()
primary = read_raw(out / 'physical-probe.stdout')
validate(primary, 'native-rank', 32)
(out / 'native-rank-fixed32.json').write_text(json.dumps(primary, indent=2, allow_nan=False) + '\n')
environment = dict(os.environ)
environment['LD_LIBRARY_PATH'] = str(out)
records = []
for selection, bound in [('native-denominators', 32), ('native', 32), ('all', None)]:
    label = selection + ('-fixed32' if bound else '-whole')
    report_path = out / (label + '.json')
    assert not report_path.exists(), report_path
    verify()
    command = ['flock', '/tmp/ninjars-symbolica-tests.lock', str(out / 'physical-probe'),
               str(root / 'examples/graphs/physical/gg-hhh/top-pentagon-26.dot'), '1024', selection]
    if bound is not None:
        command.append(str(bound))
    record = {'label': label, 'argv': command, 'LD_LIBRARY_PATH': environment['LD_LIBRARY_PATH'],
              'before_sha256': {p: sha(p) for p in artifacts}}
    records.append(record)
    (out / 'same-artifact-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, 'starting', flush=True)
    with (out / (label + '.stdout')).open('w') as stdout, (out / (label + '.stderr')).open('w') as stderr:
        run = subprocess.run(command, input=(out / 'input.txt').read_text(), text=True,
                             stdout=stdout, stderr=stderr, env=environment)
    record['returncode'] = run.returncode
    record['after_sha256'] = {p: sha(p) for p in artifacts}
    record['artifact_hashes_unchanged'] = record['before_sha256'] == record['after_sha256']
    (out / 'same-artifact-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert record['artifact_hashes_unchanged']
    if run.returncode:
        sys.exit(run.returncode)
    result = read_raw(out / (label + '.stdout'))
    validate(result, selection, bound)
    report_path.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    record['report'] = str(report_path)
    record['report_sha256'] = sha(report_path)
    verify()
    record['sources_and_dependencies_unchanged'] = True
    (out / 'same-artifact-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, 'passed', flush=True)

