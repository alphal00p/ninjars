"""Freeze the copied release artifacts, verify loader paths, lock only numerics."""
import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path.cwd()
sys.path.insert(0,str(root/'validation/performance/shared_provider'))
import run_physical
original_run=subprocess.run

def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def locked_run(command,*args,**kwargs):
 if isinstance(command,(list,tuple)) and pathlib.Path(str(command[0])).name=='physical-probe':
  binary=pathlib.Path(command[0]);out=binary.parent;library=out/'libninjars_shared_provider_probe.so';input_path=out/'input.txt'
  for p in [binary,library]:p.chmod(0o555)
  input_path.chmod(0o444)
  before={str(p):sha(p) for p in [binary,library,input_path]}
  environment=dict(os.environ)
  environment['LD_LIBRARY_PATH']=str(out)
  for name,tool in [('needed',['readelf','-d',str(binary)]),('loader',['ldd',str(binary)])]:
   check=original_run(tool,env=environment,capture_output=True,text=True,check=True)
   (out/('physical-probe-'+name+'.txt')).write_text(check.stdout+check.stderr)
   if name=='loader':assert str(library) in check.stdout,'copied library absent from runtime loader output'
  record={'argv':['flock','/tmp/ninjars-symbolica-tests.lock',*map(str,command)],'LD_LIBRARY_PATH':environment['LD_LIBRARY_PATH'],'before_sha256':before}
  (out/'primary-execution.json').write_text(json.dumps(record,indent=2)+'\n')
  kwargs['env']=environment
  result=original_run(record['argv'],*args,**kwargs)
  record['returncode']=result.returncode;record['after_sha256']={p:sha(p) for p in before}
  record['unchanged']=record['before_sha256']==record['after_sha256']
  (out/'primary-execution.json').write_text(json.dumps(record,indent=2)+'\n')
  assert record['unchanged']
  return result
 return original_run(command,*args,**kwargs)
subprocess.run=locked_run
run_physical.main()
