"""Compile and inspect the ordinary timing launcher; do not execute it."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / 'target/validation/native-block-release32'
reference = Path('/shared/external/ninja/target/reference-uncached-v2')
library = out / 'libninjars_shared_provider_probe.so'
binary = out / 'physical-timing'
assert library.is_file() and not binary.exists()

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

before = sha(library)
fortran = Path(subprocess.check_output(['gfortran', '-print-file-name=libgfortran.so'], text=True).strip())
command = ['g++', '-O3', '-std=c++17', '-Wall', '-Wextra', '-Werror',
           '-I' + str(reference / 'ninja-source/src'), '-I' + str(reference / 'ninja-build/src'),
           '-I' + str(reference / 'ninja-build'),
           str(root / 'validation/performance/shared_provider/physical_timing.cc'), str(library),
           str(reference / 'ninja-build/src/.libs/libninja.a'), str(reference / 'oneloop/libavh_olo.a'),
           str(fortran), '-lquadmath', '-Wl,-rpath,' + str(out), '-Wl,-rpath,' + str(fortran.parent),
           '-o', str(binary)]
record = {'argv': command, 'library_before_sha256': before, 'execution_performed': False}
(out / 'timing-launcher-build.json').write_text(json.dumps(record, indent=2) + '\n')
with (out / 'timing-launcher-build.stdout').open('w') as stdout, (out / 'timing-launcher-build.stderr').open('w') as stderr:
    result = subprocess.run(command, text=True, stdout=stdout, stderr=stderr)
record['returncode'] = result.returncode
record['library_after_sha256'] = sha(library)
(out / 'timing-launcher-build.json').write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0 and before == sha(library)
binary.chmod(0o555)
record['binary_sha256'] = sha(binary)
environment = dict(os.environ)
environment['LD_LIBRARY_PATH'] = str(out)
record['LD_LIBRARY_PATH'] = str(out)
record['loader_commands'] = []
for name, command in [('needed', ['readelf', '-d', str(binary)]), ('loader', ['ldd', str(binary)])]:
    check = subprocess.run(command, env=environment, capture_output=True, text=True)
    path = out / ('physical-timing-' + name + '.txt')
    path.write_text(check.stdout + check.stderr)
    record['loader_commands'].append({'argv': command, 'returncode': check.returncode,
                                     'output': str(path), 'output_sha256': sha(path)})
    (out / 'timing-launcher-build.json').write_text(json.dumps(record, indent=2) + '\n')
    assert check.returncode == 0
    if name == 'loader':
        assert str(library) in check.stdout, 'copied library absent from loader output'
print('Ordinary physical-timing compiled and loader verified; not executed.')
