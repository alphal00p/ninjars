"""Reuse one copied correctness executable/library/input for independent modes."""
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd();out=root/'target/validation/native-block-physical'
sys.path.insert(0,str(root/'validation/performance/shared_provider'))
from kernel_selection import validate_report

def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
base=json.loads((out/'result.json').read_text())
assert base['success'] and base['unchanged_runtime_sources']
for path,digest in base['source_sha256'].items():assert sha(root/path)==digest,path
artifacts={path:sha(path) for path in base['artifacts_sha256']}
assert artifacts==base['artifacts_sha256']
records=[]
for selection,bound in [('native-denominators',7),('native',7),('all',None)]:
 label=selection+('-fixed7' if bound else '-whole')
 command=['flock','/tmp/ninjars-symbolica-tests.lock',str(out/'physical-probe'),str(root/'examples/graphs/physical/gg-hhh/top-pentagon-26.dot'),'32',selection]
 if bound:command.append(str(bound))
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
  run=subprocess.run(command,input=(out/'input.txt').read_text(),text=True,stdout=stdout,stderr=stderr)
 record={'label':label,'argv':command,'returncode':run.returncode}
 records.append(record)
 (out/'same-artifact-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if run.returncode:sys.exit(run.returncode)
 results=[json.loads(line) for line in (out/(label+'.stdout')).read_text().splitlines() if line.startswith('{')]
 assert len(results)==1
 result=results[0];assert result['success']
 validate_report(result,'symbolica' if selection=='all' else selection,True,all_catalog=selection=='all',native_block_rows=bound,execution_controls=bound is not None)
 path=out/(label+'.json');path.write_text(json.dumps(result,indent=2)+'\n')
 record['report']=str(path);record['sha256']=sha(path)
 record['artifact_hashes_unchanged']=all(sha(path)==digest for path,digest in artifacts.items())
 assert record['artifact_hashes_unchanged']
 (out/'same-artifact-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,'passed',flush=True)
for path,digest in base['source_sha256'].items():assert sha(root/path)==digest,path
