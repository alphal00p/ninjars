"""Run the existing correctness driver; lock only the numerical executable."""
import pathlib,subprocess,sys
sys.path.insert(0,str(pathlib.Path.cwd()/'validation/performance/shared_provider'))
import run_physical
original_run=subprocess.run
def lock_numerical(command,*args,**kwargs):
 if isinstance(command,(list,tuple)) and pathlib.Path(str(command[0])).name=='physical-probe':
  command=['flock','/tmp/ninjars-symbolica-tests.lock',*command]
 return original_run(command,*args,**kwargs)
subprocess.run=lock_numerical
run_physical.main()
