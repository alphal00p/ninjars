import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd();prefix='ninjars-native-block-';phase=sys.argv[1]
records={}
def digest(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for line in pathlib.Path('/tmp/'+prefix+phase+'-build.jsonl').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r.get('executable'):
  records[r['target']['name']]={'path':r['executable']}
preserved=root/'target/validation/native-block-artifacts';preserved.mkdir(parents=True,exist_ok=True)
for name,r in records.items():
 r['sha256']=digest(r['path']);copy=preserved/(phase+'-'+name+'-'+r['sha256'][:12]);subprocess.run(['cp','--reflink=auto',r['path'],str(copy)],check=True);copy.chmod(0o555)
 assert digest(copy)==r['sha256'];r['preserved_path']=str(copy)
pathlib.Path('/tmp/'+prefix+phase+'-executables.json').write_text(json.dumps(records,indent=2)+'\n')
commands=[]
for name,pattern in [s.split(':',1) for s in sys.argv[2:]]:
 for r in records.values():assert digest(r['path'])==r['sha256']
 # The integration test's embedded CARGO_BIN_EXE points at the freshly built
 # artifact. Execute before another feature build; retain its matching copy.
 command=['flock','/tmp/ninjars-symbolica-tests.lock',records[name]['path'],pattern,'--test-threads=1','--nocapture']
 with open('/tmp/'+prefix+phase+'-'+name+'-'+pattern+'.log','w') as log:run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 commands.append({'argv':command,'returncode':run.returncode})
 pathlib.Path('/tmp/'+prefix+phase+'-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if run.returncode:sys.exit(run.returncode)
for r in records.values():assert digest(r['path'])==r['sha256']
print(phase,'passed; preserved',len(records),'executables')
